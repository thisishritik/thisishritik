<!-- Replace every YOUR-USERNAME with your GitHub username -->

<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&customColorList=12,14,30&height=220&section=header&text=Hritik%20Kumar&fontSize=58&fontColor=ffffff&animation=fadeIn&fontAlignY=36&desc=BCA%20Student%20%C2%B7%20Aspiring%20Software%20Developer&descSize=18&descAlignY=58" width="100%" />

<a href="https://git.io/typing-svg">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=500&size=22&duration=3000&pause=1000&color=00D9FF&center=true&vCenter=true&width=600&lines=Hi%2C+I'm+Hritik+%F0%9F%91%8B;BCA+Student+from+Saharsa%2C+Bihar;Learning+C%2C+Java%2C+Python+%26+Web+Dev;Building+one+project+at+a+time" alt="Typing animation" />
</a>

<br/>

<img src="https://fonts.gstatic.com/s/e/notoemoji/latest/1f4bb/512.gif" width="64" alt="laptop" />
<img src="https://fonts.gstatic.com/s/e/notoemoji/latest/1f680/512.gif" width="64" alt="rocket" />
<img src="https://fonts.gstatic.com/s/e/notoemoji/latest/1f9e0/512.gif" width="64" alt="brain" />
<img src="https://fonts.gstatic.com/s/e/notoemoji/latest/1f4aa/512.gif" width="64" alt="strength" />

</div>

---

## About Me

- 🎓 Pursuing **BCA** (Bachelor of Computer Applications)
- 📜 **ADIT** (Grade A, 91%) and **ADCA** (Grade A, 84%) certified
- 🌱 Learning data structures, algorithms and full-stack web development
- 🗣️ Hindi (native) · English
- 🏋️ Outside of code: fitness and bodybuilding

---

## Tech Stack

<div align="center">

<img src="https://skillicons.dev/icons?i=c,cpp,java,py,html,css,js,mysql,git,github,vscode&theme=dark" alt="Skills" />

</div>

### BCA Fundamentals

| Area | Topics |
|---|---|
| Programming | C, C++, Java, Python, Object-Oriented Programming |
| Core CS | Data Structures & Algorithms, Operating Systems, Computer Organization |
| Databases | DBMS, SQL, Normalization, ER Modeling |
| Networking | Computer Networks, Internet Basics, Web Technologies |
| Engineering | Software Engineering, SDLC, System Analysis & Design |
| Mathematics | Discrete Mathematics, Numerical & Statistical Methods |
| Productivity | MS Word, Excel, PowerPoint, Computer Fundamentals |

**Soft skills:** Communication · Teamwork · Quick Learner · Punctual · Adaptable

---

## GitHub Stats

<div align="center">

<img height="170" src="https://github-readme-stats.vercel.app/api?username=YOUR-USERNAME&show_icons=true&theme=transparent&hide_border=true&title_color=00D9FF&icon_color=00D9FF&text_color=9e9e9e" alt="Stats" />
<img height="170" src="https://github-readme-stats.vercel.app/api/top-langs/?username=YOUR-USERNAME&layout=compact&theme=transparent&hide_border=true&title_color=00D9FF&text_color=9e9e9e" alt="Top languages" />

<img src="https://streak-stats.demolab.com?user=YOUR-USERNAME&theme=transparent&hide_border=true&ring=00D9FF&fire=00D9FF&currStreakLabel=00D9FF" alt="Streak" />

</div>

---

## 3D Contribution Graph

<div align="center">

<img src="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/main/profile-3d-contrib/profile-night-rainbow.svg" alt="3D contribution graph" width="100%" />

</div>

## Contribution Snake

<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/github-snake-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/github-snake.svg" />
  <img alt="Contribution snake" src="https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-USERNAME/output/github-snake.svg" />
</picture>

</div>

## Activity Graph

<div align="center">

<img src="https://github-readme-activity-graph.vercel.app/graph?username=YOUR-USERNAME&bg_color=0d1117&color=00D9FF&line=00D9FF&point=ffffff&area=true&hide_border=true" alt="Activity graph" width="100%" />

</div>

---

## Education & Certifications

- **BCA** · Online Degree Program (currently enrolled)
- **ADIT** · Grade A, 91%
- **ADCA** · Grade A, 84%
- **Kushal Yuva Program (KYP)** · Bihar Skill Development Mission, Govt. of Bihar

## Currently Focusing On

- Strengthening DSA with Python / C++
- Building small projects in HTML, CSS and JavaScript
- Learning SQL through hands-on practice
- Taking first steps in open source

---

<div align="center">

## Connect

<a href="mailto:hritikkumar.it@gmail.com"><img src="https://img.shields.io/badge/Email-00D9FF?style=for-the-badge&logo=gmail&logoColor=black" alt="Email" /></a>
<a href="https://github.com/YOUR-USERNAME"><img src="https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white" alt="GitHub" /></a>
<a href="https://linkedin.com/in/YOUR-USERNAME"><img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn" /></a>

<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&customColorList=12,14,30&height=120&section=footer" width="100%" />

</div>
